from ursina import *
from math import sin, cos, radians
from ursina.prefabs.first_person_controller import FirstPersonController
from perlin_noise import PerlinNoise

app = Ursina()
Sky(color=color.blue)

CHUNK_SIZE = 4
WORLD_CHUNKS_X = 4
WORLD_CHUNKS_Z = 4
RENDER_DISTANCE = 1
RENDER_HEIGHT = 5

MAX_HEIGHT = 12
SCALE = 30
OCTAVES = 4
PERSISTENCE = 0.5
LACUNARITY = 2.0

noise = PerlinNoise(octaves=OCTAVES)

class Voxel(Button):
    def __init__(self, position=(0,0,0), color=color.white, parent_entity=scene):
        super().__init__(
            parent=parent_entity,
            position=position,
            model='cube',
            texture='white_cube',
            origin_y=0,
            color=color,
            highlight_color=color
        )
        self.is_block = True

class Chunk(Entity):
    def __init__(self, chunk_x, chunk_z):
        super().__init__(parent=scene)
        self.chunk_x = chunk_x
        self.chunk_z = chunk_z
        self.blocks = []

        for z in range(CHUNK_SIZE):
            for x in range(CHUNK_SIZE):
                world_x = chunk_x * CHUNK_SIZE + x
                world_z = chunk_z * CHUNK_SIZE + z

                nx = world_x / SCALE
                nz = world_z / SCALE
                elevation = 0
                amplitude = 1
                frequency = 1
                max_value = 0
                for _ in range(OCTAVES):
                    elevation += noise([nx * frequency, nz * frequency]) * amplitude
                    max_value += amplitude
                    amplitude *= PERSISTENCE
                    frequency *= LACUNARITY
                height = int((elevation / max_value + 1) / 2 * MAX_HEIGHT)
                if height < 1:
                    height = 1

                for y in range(height):
                    if y == 0:
                        c = color.black
                    elif y < height - 3:
                        c = color.gray
                    elif y < height - 1:
                        c = color.brown
                    else:
                        c = color.green

                    voxel = Voxel(position=(world_x, y, world_z), color=c, parent_entity=self)
                    self.blocks.append(voxel)

chunks = []
for cz in range(WORLD_CHUNKS_Z):
    for cx in range(WORLD_CHUNKS_X):
        chunk = Chunk(cx, cz)
        chunks.append(chunk)

mid_pos = [x for x in range(CHUNK_SIZE)]
middle = sum(mid_pos) / len(mid_pos)

player = FirstPersonController()
player.position = (middle, MAX_HEIGHT + 2, middle)
player.jump_height = 1

camera.parent = player
camera.position = (0,1.5,0)
mouse.locked = True
mouse_sensitivity = 40

crosshair = Entity(parent=camera.ui, model='circle', color=color.white, scale=0.01)

highlight = Entity(model='cube', color=color.yellow, scale=1.05, visible=False)

def can_move(new_position):
    for chunk in chunks:
        for e in chunk.blocks:
            if getattr(e, 'is_block', False):
                if (abs(new_position.x - e.position.x) < 0.5 and abs(new_position.y - e.position.y) < 0.95 and abs(new_position.z - e.position.z) < 0.5):
                    return False
    return True

def update():
    if mouse.locked:
        player.rotation_y += mouse.velocity[0]*mouse_sensitivity
        camera.rotation_x -= mouse.velocity[1]*mouse_sensitivity
        camera.rotation_x = clamp(camera.rotation_x, -90, 90)

        speed = 0.05
        forward = Vec3(sin(radians(player.rotation_y)), 0, cos(radians(player.rotation_y)))
        right   = Vec3(sin(radians(player.rotation_y + 90)), 0, cos(radians(player.rotation_y + 90)))

        if held_keys['w']:
            new_pos = player.position + forward * speed
            if can_move(new_pos):
                player.position = new_pos
        if held_keys['s']:
            new_pos = player.position - forward * speed
            if can_move(new_pos):
                player.position = new_pos
        if held_keys['a']:
            new_pos = player.position - right * speed
            if can_move(new_pos):
                player.position = new_pos
        if held_keys['d']:
            new_pos = player.position + right * speed
            if can_move(new_pos):
                player.position = new_pos

        player_chunk_x = int(player.x // CHUNK_SIZE)
        player_chunk_z = int(player.z // CHUNK_SIZE)
        for chunk in chunks:
            dist_x = abs(chunk.chunk_x - player_chunk_x)
            dist_z = abs(chunk.chunk_z - player_chunk_z)
            chunk.visible = dist_x <= RENDER_DISTANCE and dist_z <= RENDER_DISTANCE
            if chunk.visible:
                for block in chunk.blocks:
                    block.visible = abs(block.y - player.y) <= RENDER_HEIGHT

        hit_info = raycast(camera.world_position, camera.forward, distance=5, traverse_target=scene)
        if hit_info.hit and getattr(hit_info.entity, 'is_block', False):
            highlight.visible = True
            highlight.position = hit_info.entity.position  # center aligned
        else:
            highlight.visible = False

def is_inside_player(pos):
    player_min = player.position + Vec3(-0.5, 0.5, -0.5)
    player_max = player.position + Vec3(0.5, 2, 0.5)
    return (player_min.x <= pos.x <= player_max.x and
            player_min.y <= pos.y <= player_max.y and
            player_min.z <= pos.z <= player_max.z)
def create_block_with_outline(position=(0,0,0), block_color=color.green, outline_color=color.black):
    x, y, z = position
    t = 0.05  # edge thickness

    # Main cube
    Entity(model='cube', color=block_color, position=position)

    # Top edges (y+0.5 because cube center is at y)
    Entity(model='cube', color=outline_color, position=(x, y+0.5, z+0.5), scale=(1, t, t))
    Entity(model='cube', color=outline_color, position=(x, y+0.5, z-0.5), scale=(1, t, t))
    Entity(model='cube', color=outline_color, position=(x-0.5, y+0.5, z), scale=(t, t, 1))
    Entity(model='cube', color=outline_color, position=(x+0.5, y+0.5, z), scale=(t, t, 1))

    # Vertical edges
    Entity(model='cube', color=outline_color, position=(x-0.5, y, z-0.5), scale=(t,1,t))
    Entity(model='cube', color=outline_color, position=(x+0.5, y, z-0.5), scale=(t,1,t))
    Entity(model='cube', color=outline_color, position=(x-0.5, y, z+0.5), scale=(t,1,t))
    Entity(model='cube', color=outline_color, position=(x+0.5, y, z+0.5), scale=(t,1,t))



def input(key):
    if key == 'right mouse down' and mouse.locked:
        hit_info = raycast(camera.world_position, camera.forward, distance=6)
        if hit_info.hit:
            place_pos = hit_info.entity.position + hit_info.normal
            if not is_inside_player(place_pos):
                Voxel(position=place_pos, parent_entity=hit_info.entity.parent)

    if key == 'left mouse down' and mouse.locked:
        if mouse.hovered_entity:
            # check distance to player
            if distance(mouse.hovered_entity.position, player.position) <= 6:
                for chunk in chunks:
                    if mouse.hovered_entity in chunk.blocks:
                        chunk.blocks.remove(mouse.hovered_entity)
                        break
                destroy(mouse.hovered_entity)

    if key == 'l':
        mouse.locked = not mouse.locked

app.run()
